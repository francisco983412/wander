/* WANDER · Servidor de edición (Cloudflare Workers + KV)
   Rutas:
     GET  /api/contenido      contenido publicado (público)
     POST /api/login          { password } -> { token }     (contraseña = secreto ADMIN_PASSWORD)
     PUT  /api/contenido      guarda y publica el contenido  (requiere token)
     POST /api/media          sube una imagen -> { url }      (requiere token)
     GET  /api/media/:id      sirve una imagen subida (público)
   Configuración (ver LEEME-CLOUDFLARE.txt):
     - Almacenamiento KV "WANDER_KV": lo crea Wrangler solo al publicar (wrangler.jsonc)
     - Secreto ADMIN_PASSWORD (y opcional TOKEN_SECRET) en el panel de Cloudflare */

const TIPOS = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif' };
const HORAS_SESION = 12;
const RESPALDOS = 10;
const MAX_CONTENIDO = 4 * 1024 * 1024;
const MAX_IMAGEN = 5 * 1024 * 1024;
const enc = new TextEncoder();

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }
});

const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');

async function firmar(env, texto) {
  const clave = await crypto.subtle.importKey('raw', enc.encode(`${env.ADMIN_PASSWORD}|${env.TOKEN_SECRET || 'wander'}`),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', clave, enc.encode(String(texto))));
}

/* Comparación en tiempo constante (sobre el SHA-256 de ambos textos) */
async function iguales(a, b) {
  const [x, y] = await Promise.all([a, b].map((t) => crypto.subtle.digest('SHA-256', enc.encode(String(t)))));
  const ax = new Uint8Array(x);
  const ay = new Uint8Array(y);
  let dif = 0;
  for (let i = 0; i < ax.length; i++) dif |= ax[i] ^ ay[i];
  return dif === 0;
}

async function autorizado(request, env) {
  if (!env.ADMIN_PASSWORD) return false;
  const m = (request.headers.get('authorization') || '').match(/^Bearer (\d+)\.([a-f0-9]{64})$/);
  if (!m || Number(m[1]) < Date.now()) return false;
  return iguales(m[2], await firmar(env, m[1]));
}

export async function manejarApi(request, env, ctx, ruta) {
  const metodo = request.method;
  const kv = env.WANDER_KV;

  try {
    if (ruta === 'contenido' && metodo === 'GET') {
      // null = aún no se ha publicado nada (la web usa js/contenido.js)
      const contenido = kv ? await kv.get('contenido', { type: 'json' }) : null;
      return json(contenido || null);
    }

    if (!kv) return json({ error: 'Falta conectar el almacenamiento WANDER_KV en Cloudflare' }, 500);

    if (ruta === 'login' && metodo === 'POST') {
      if (!env.ADMIN_PASSWORD) return json({ error: 'Falta configurar ADMIN_PASSWORD en Cloudflare' }, 500);
      let cuerpo = {};
      try { cuerpo = await request.json(); } catch { /* cuerpo vacío */ }
      await new Promise((r) => setTimeout(r, 400)); // frena intentos repetidos
      if (!(await iguales(cuerpo.password || '', env.ADMIN_PASSWORD))) return json({ error: 'Contraseña incorrecta' }, 401);
      const exp = Date.now() + HORAS_SESION * 3600 * 1000;
      return json({ token: `${exp}.${await firmar(env, exp)}` });
    }

    if (ruta === 'contenido' && metodo === 'PUT') {
      if (!(await autorizado(request, env))) return json({ error: 'No autorizado' }, 401);
      const texto = await request.text();
      if (texto.length > MAX_CONTENIDO) return json({ error: 'Contenido demasiado grande' }, 413);
      let obj;
      try { obj = JSON.parse(texto); } catch { return json({ error: 'Formato inválido' }, 400); }
      if (!obj || typeof obj !== 'object' || !obj.portafolio) return json({ error: 'Formato inválido' }, 400);

      const anterior = await kv.get('contenido');
      if (anterior) {
        await kv.put(`respaldo:${Date.now()}-${crypto.randomUUID().slice(0, 6)}`, anterior);
        const { keys } = await kv.list({ prefix: 'respaldo:' });
        const viejos = keys.map((k) => k.name).sort().reverse().slice(RESPALDOS);
        await Promise.all(viejos.map((k) => kv.delete(k)));
      }
      await kv.put('contenido', JSON.stringify(obj));
      return json({ ok: true, actualizado: new Date().toISOString() });
    }

    if (ruta === 'media' && metodo === 'POST') {
      if (!(await autorizado(request, env))) return json({ error: 'No autorizado' }, 401);
      const tipo = (request.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
      const ext = TIPOS[tipo];
      if (!ext) return json({ error: 'Tipo de archivo no permitido' }, 415);
      const bytes = await request.arrayBuffer();
      if (bytes.byteLength > MAX_IMAGEN) return json({ error: 'Imagen demasiado grande' }, 413);
      const id = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}.${ext}`;
      await kv.put(`media:${id}`, bytes, { metadata: { tipo } });
      return json({ url: `/api/media/${id}` });
    }

    const m = ruta.match(/^media\/([\w.-]+)$/);
    if (m && metodo === 'GET') {
      const cache = typeof caches !== 'undefined' ? caches.default : null;
      const enCache = cache && await cache.match(request);
      if (enCache) return enCache;
      const r = await kv.getWithMetadata(`media:${m[1]}`, { type: 'arrayBuffer' });
      if (!r || !r.value) return json({ error: 'No encontrado' }, 404);
      const resp = new Response(r.value, {
        headers: {
          'content-type': (r.metadata && r.metadata.tipo) || 'application/octet-stream',
          'cache-control': 'public, max-age=31536000, immutable',
          'x-content-type-options': 'nosniff'
        }
      });
      if (cache) ctx.waitUntil(cache.put(request, resp.clone()));
      return resp;
    }

    return json({ error: 'No encontrado' }, 404);
  } catch (e) {
    console.error(e);
    return json({ error: 'Error del servidor' }, 500);
  }
}
