/* WANDER · Render de la página a partir de js/contenido.js (o del borrador local del editor) */
(() => {
  'use strict';
  document.documentElement.classList.add('js');

  const KEY = 'wander-borrador-v1';
  const $ = (s, r = document) => r.querySelector(s);
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Datos ---------- */
  function normalizar(d) {
    d = d && typeof d === 'object' ? d : {};
    d.perfil = d.perfil || {};
    d.perfil.especialidades = Array.isArray(d.perfil.especialidades) ? d.perfil.especialidades : [];
    d.portafolio = d.portafolio || {};
    d.portafolio.secciones = Array.isArray(d.portafolio.secciones) ? d.portafolio.secciones : [];
    d.portafolio.secciones.forEach((s) => {
      s.items = Array.isArray(s.items) ? s.items : [];
      s.items.forEach((i) => { i.imagenes = Array.isArray(i.imagenes) ? i.imagenes : []; });
    });
    d.recursos = d.recursos || {};
    d.recursos.items = Array.isArray(d.recursos.items) ? d.recursos.items : [];
    d.contacto = d.contacto || {};
    return d;
  }

  /* publicado = lo que ven los visitantes (servidor, o js/contenido.js si no hay servidor)
     data      = lo que se pinta (igual a publicado, o el borrador mientras el dueño edita) */
  const base = normalizar(clone(window.WANDER_CONTENIDO || {}));
  const state = { data: clone(base), publicado: base, pendiente: false, servidor: false };

  /* En Cloudflare un cambio publicado tarda hasta ~1 minuto en llegar a todos los servidores.
     Durante unos minutos, el navegador de quien publicó usa su copia para no ver la versión vieja. */
  const KEY_PUBLICADO = 'wander-ultimo-publicado';
  function usarUltimoPublicado(delServidor) {
    try {
      const local = JSON.parse(localStorage.getItem(KEY_PUBLICADO) || 'null');
      if (!local || !local._actualizado) return;
      const reciente = Date.now() - local._actualizado < 5 * 60 * 1000;
      const servidorAtrasado = !delServidor || (delServidor._actualizado || 0) < local._actualizado;
      if (reciente && servidorAtrasado) state.publicado = normalizar(local);
      else localStorage.removeItem(KEY_PUBLICADO);
    } catch (e) { /* nada */ }
  }

  async function cargarPublicado() {
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 4000);
      const r = await fetch('/api/contenido', { cache: 'no-store', signal: ctrl.signal });
      clearTimeout(t);
      const esJson = (r.headers.get('content-type') || '').includes('json');
      state.servidor = esJson && r.ok;
      if (state.servidor) {
        const d = await r.json();
        if (d && d.portafolio) state.publicado = normalizar(d);
        usarUltimoPublicado(d);
      }
    } catch (e) { /* sin servidor: se usa js/contenido.js */ }
    state.data = clone(state.publicado);
  }

  /* ---------- Utilidades ---------- */
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'text') el.textContent = v;
        else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    for (const k of kids.flat(Infinity)) {
      if (k == null || k === false || k === '') continue;
      el.append(k instanceof Node ? k : document.createTextNode(String(k)));
    }
    return el;
  }

  const ICONOS = {
    play: '<path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.6-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5Z"/>',
    galeria: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 15-4.5-4.5L6 21"/>',
    flecha: '<path d="M7 17 17 7M8 7h9v9"/>',
    izq: '<path d="M15 18 9 12l6-6"/>',
    der: '<path d="m9 18 6-6-6-6"/>',
    cerrar: '<path d="M6 6l12 12M18 6 6 18"/>',
    descarga: '<path d="M12 4v11M7 10l5 5 5-5M4 20h16"/>',
    wa: '<path d="M20.5 11.6a8.5 8.5 0 0 1-12.6 7.4L3.5 20.5l1.6-4.3A8.5 8.5 0 1 1 20.5 11.6Z"/><path d="M8.8 8.6c.3 2.9 3.3 6 6.4 6.6l1.1-1.4-1.9-1-1 .8c-1-.4-2.3-1.6-2.8-2.8l.8-1-1-1.9Z"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/>',
    ig: '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r=".6"/>'
  };
  function icono(nombre, extra) {
    const s = document.createElement('span');
    s.className = 'ico' + (extra ? ' ' + extra : '');
    s.setAttribute('aria-hidden', 'true');
    s.innerHTML = '<svg viewBox="0 0 24 24">' + (ICONOS[nombre] || '') + '</svg>';
    return s;
  }

  /* Solo se aceptan enlaces http(s), rutas relativas o imágenes incrustadas */
  function seguro(u) {
    u = String(u || '').trim();
    if (!u) return '';
    if (/^data:image\/(png|jpe?g|webp|gif|avif);base64,/i.test(u)) return u;
    if (/^https?:\/\//i.test(u)) return u;
    if (/^[a-z][a-z0-9+.-]*:/i.test(u) || u.startsWith('//')) return '';
    return u;
  }

  /* Texto con *palabras destacadas* en naranja */
  function rico(el, str) {
    el.textContent = '';
    String(str || '').split(/(\*[^*]+\*)/).forEach((p) => {
      if (/^\*[^*]+\*$/.test(p)) el.append(h('em', { text: p.slice(1, -1) }));
      else if (p) el.append(p);
    });
  }

  /* Reconoce enlaces de YouTube, Vimeo, Google Drive, Instagram, TikTok o archivos de video */
  function media(url) {
    url = String(url || '').trim();
    if (!url) return null;
    let m;
    if ((m = url.match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/)|youtu\.be\/)([\w-]{11})/))) {
      return { plataforma: 'YouTube', tipo: 'iframe', src: `https://www.youtube-nocookie.com/embed/${m[1]}?autoplay=1&rel=0&playsinline=1`, thumb: `https://i.ytimg.com/vi/${m[1]}/hqdefault.jpg` };
    }
    if ((m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/))) {
      return { plataforma: 'Vimeo', tipo: 'iframe', src: `https://player.vimeo.com/video/${m[1]}?autoplay=1`, thumb: `https://vumbnail.com/${m[1]}.jpg` };
    }
    if ((m = url.match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:.*&)?id=)([\w-]{10,})/))) {
      return { plataforma: 'Google Drive', tipo: 'iframe', src: `https://drive.google.com/file/d/${m[1]}/preview`, thumb: `https://drive.google.com/thumbnail?id=${m[1]}&sz=w1200` };
    }
    if ((m = url.match(/instagram\.com\/(?:[\w.]+\/)?(reel|reels|p|tv)\/([\w-]+)/))) {
      return { plataforma: 'Instagram', tipo: 'iframe', src: `https://www.instagram.com/${m[1] === 'reels' ? 'reel' : m[1]}/${m[2]}/embed` };
    }
    if ((m = url.match(/tiktok\.com\/.*\/video\/(\d+)/))) {
      return { plataforma: 'TikTok', tipo: 'iframe', src: `https://www.tiktok.com/embed/v2/${m[1]}` };
    }
    if (/\.(mp4|webm|mov|m4v)(\?|#|$)/i.test(url) && seguro(url)) {
      return { plataforma: 'Archivo de video', tipo: 'video', src: seguro(url) };
    }
    return null;
  }

  function miniatura(it) {
    return seguro(it.miniatura)
      || (it.tipo === 'galeria' ? seguro(it.imagenes[0]) : '')
      || (media(it.video) || {}).thumb
      || '';
  }

  const uid = () => 'x' + Math.random().toString(36).slice(2, 9);
  const pad = (n) => String(n).padStart(2, '0');
  const editando = () => document.body.classList.contains('editando');

  /* ---------- Revelado al hacer scroll ---------- */
  let primerPintado = true;
  const io = (!reduce && 'IntersectionObserver' in window)
    ? new IntersectionObserver((es) => es.forEach((e) => {
        if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); }
      }), { rootMargin: '0px 0px -8% 0px', threshold: .05 })
    : null;
  function revelar(root) {
    root.querySelectorAll('.revela:not(.visible)').forEach((el) => {
      if (io && primerPintado) io.observe(el); else el.classList.add('visible');
    });
  }

  /* ---------- Perfil / Quién soy ---------- */
  function pintarPerfil() {
    if (!$('#pTitular')) return;
    const p = state.data.perfil;
    $('#pRol').textContent = p.rol || '';
    rico($('#pTitular'), p.titular);
    $('#pSubtitulo').textContent = p.subtitulo || '';
    rico($('#pSaludo'), p.saludo);

    const bio = $('#pBio');
    bio.textContent = '';
    String(p.bio || '').split(/\n\s*\n/).filter((t) => t.trim()).forEach((t) => bio.append(h('p', { text: t.trim() })));

    const esp = $('#pEspecialidades');
    esp.textContent = '';
    p.especialidades.filter((e) => e && (e.titulo || e.texto)).forEach((e) => {
      esp.append(h('li', null, h('strong', { text: e.titulo || '' }), h('span', { text: e.texto || '' })));
    });
    esp.hidden = !esp.children.length;

    const foto = $('#pFoto');
    foto.textContent = '';
    const src = seguro(p.foto);
    if (src) {
      const img = h('img', { src, alt: `Retrato de ${p.nombre || 'Wander'}`, decoding: 'async' });
      img.addEventListener('error', () => img.replaceWith(monograma(p)));
      foto.append(img);
    } else {
      foto.append(monograma(p));
    }
    foto.parentElement.classList.toggle('con-foto', !!src);
    $('#camNombre').textContent = (p.nombre || 'Wander').toUpperCase();
  }
  const monograma = (p) => h('span', { class: 'cam-monograma', text: (p.nombre || 'W').trim().charAt(0).toUpperCase() });

  /* ---------- Portafolio ---------- */
  function placeholder(i) {
    return h('span', { class: 'obra-ph ph-' + (i % 4) });
  }

  function tarjeta(it, i, formato) {
    const src = miniatura(it);
    const esGal = it.tipo === 'galeria';
    let fondo;
    if (src) {
      fondo = h('img', { src, alt: '', loading: 'lazy', decoding: 'async' });
      fondo.addEventListener('error', () => fondo.replaceWith(placeholder(i)));
    } else {
      fondo = placeholder(i);
    }
    const fotos = esGal ? it.imagenes.filter((x) => seguro(x)).length : 0;
    const meta = [it.categoria, it.rol].filter(Boolean).join(' · ');
    return h('button', { class: 'obra', type: 'button', 'aria-label': `Ver ${it.titulo || 'proyecto'}`, onclick: () => abrirVisor(it, formato) },
      h('span', { class: 'obra-media', 'data-formato': formato },
        fondo,
        h('span', { class: 'obra-num', text: pad(i + 1) }),
        fotos > 1 ? h('span', { class: 'obra-cuenta' }, icono('galeria'), String(fotos)) : null,
        h('span', { class: 'obra-play' }, icono(esGal ? 'galeria' : 'play', esGal ? 'galeria' : ''))
      ),
      h('span', { class: 'obra-info' },
        h('span', { class: 'obra-titulo', text: it.titulo || 'Sin título' }),
        meta ? h('span', { class: 'obra-meta', text: meta }) : null
      )
    );
  }

  function cabecera(sec, extra) {
    const t = h('h3', { class: 'bloque-titulo' });
    rico(t, sec.titulo || '');
    return h('div', { class: 'contenedor bloque-cab' },
      h('div', null, t, sec.descripcion ? h('p', { class: 'bloque-desc', text: sec.descripcion }) : null),
      extra || null);
  }

  function bloqueRejilla(sec, items, formato) {
    const grid = h('div', { class: 'rejilla', 'data-formato': formato });
    items.forEach((it, i) => {
      const t = tarjeta(it, i, formato);
      const envoltura = h('div', { class: 'revela' }, t);
      envoltura.style.transitionDelay = ((i % 4) * 70) + 'ms';
      grid.append(envoltura);
    });
    return h('div', { class: 'bloque', 'data-seccion': sec.id }, cabecera(sec), h('div', { class: 'contenedor' }, grid));
  }

  function bloqueCarrusel(sec, items, formato) {
    const pista = h('div', { class: 'car-pista', 'data-formato': formato, tabindex: '0', role: 'list', 'aria-label': sec.titulo ? sec.titulo.replace(/\*/g, '') : 'Carrusel' },
      items.map((it, i) => h('div', { class: 'car-item', role: 'listitem' }, tarjeta(it, i, formato))));
    const paso = () => Math.max(pista.clientWidth * 0.8, 240);
    const prev = h('button', { class: 'car-btn', type: 'button', 'aria-label': 'Anterior', onclick: () => pista.scrollBy({ left: -paso(), behavior: reduce ? 'auto' : 'smooth' }) }, icono('izq'));
    const next = h('button', { class: 'car-btn', type: 'button', 'aria-label': 'Siguiente', onclick: () => pista.scrollBy({ left: paso(), behavior: reduce ? 'auto' : 'smooth' }) }, icono('der'));
    const ctrl = h('div', { class: 'car-ctrl' }, prev, next);
    const barra = h('span', { class: 'car-barra' });
    const progreso = h('div', { class: 'car-progreso', 'aria-hidden': 'true' }, barra);

    const actualizar = () => {
      const max = pista.scrollWidth - pista.clientWidth;
      const ratio = pista.scrollWidth ? pista.clientWidth / pista.scrollWidth : 1;
      const p = max > 0 ? pista.scrollLeft / max : 0;
      barra.style.width = (ratio * 100) + '%';
      barra.style.marginLeft = (p * (1 - ratio) * 100) + '%';
      prev.disabled = pista.scrollLeft < 4;
      next.disabled = pista.scrollLeft > max - 4;
      const sobra = max <= 4;
      ctrl.style.visibility = sobra ? 'hidden' : '';
      progreso.style.visibility = sobra ? 'hidden' : '';
    };
    pista.addEventListener('scroll', actualizar, { passive: true });
    new ResizeObserver(actualizar).observe(pista);

    /* arrastrar con el mouse */
    let x0 = 0, s0 = 0, arrastre = false, movido = false;
    pista.addEventListener('pointerdown', (e) => {
      if (e.pointerType !== 'mouse' || e.button !== 0) return;
      arrastre = true; movido = false; x0 = e.clientX; s0 = pista.scrollLeft;
    });
    window.addEventListener('pointermove', (e) => {
      if (!arrastre) return;
      const dx = e.clientX - x0;
      if (!movido && Math.abs(dx) > 6) { movido = true; pista.classList.add('arrastrando'); }
      if (movido) pista.scrollLeft = s0 - dx;
    });
    window.addEventListener('pointerup', () => {
      if (!arrastre) return;
      arrastre = false;
      if (movido) {
        const left = pista.scrollLeft;
        pista.classList.remove('arrastrando');
        pista.scrollLeft = left;
      }
    });

    const bloque = h('div', { class: 'bloque revela', 'data-seccion': sec.id }, cabecera(sec, ctrl), pista, h('div', { class: 'contenedor' }, progreso));
    requestAnimationFrame(actualizar);
    return bloque;
  }

  /* Proyectos que se ven en una sección: los no ocultos, hasta el límite (si tiene) */
  function itemsVisibles(sec) {
    const visibles = sec.items.filter((i) => !i.oculto);
    const limite = parseInt(sec.limite, 10);
    return limite > 0 ? visibles.slice(0, limite) : visibles;
  }

  function pintarPortafolio() {
    const cont = $('#secciones');
    if (!cont) return;
    const port = state.data.portafolio;
    rico($('#portTitulo'), port.titulo);
    $('#portSub').textContent = port.subtitulo || '';
    cont.textContent = '';
    port.secciones.forEach((sec) => {
      if (sec.oculto) return;
      const items = itemsVisibles(sec);
      const formato = sec.formato || 'horizontal';
      if (!items.length) {
        if (editando()) cont.append(h('div', { class: 'bloque' }, cabecera(sec), h('div', { class: 'contenedor' }, h('div', { class: 'bloque-vacio', text: 'Esta sección aún no tiene proyectos visibles. Agrégalos desde el editor.' }))));
        return;
      }
      cont.append(sec.tipo === 'carrusel' ? bloqueCarrusel(sec, items, formato) : bloqueRejilla(sec, items, formato));
    });
  }

  /* ---------- Contacto ---------- */
  function limpiarIG(v) {
    return String(v || '').trim().replace(/^https?:\/\/(www\.)?instagram\.com\//i, '').replace(/^@/, '').replace(/[/?#].*$/, '');
  }
  function pintarContacto() {
    if (!$('#cTitulo')) return;
    const c = state.data.contacto;
    rico($('#cTitulo'), c.titulo);
    $('#cTexto').textContent = c.texto || '';
    const wa = String(c.whatsapp || '').replace(/\D/g, '');
    const email = String(c.email || '').trim();
    const ig = limpiarIG(c.instagram);
    const waUrl = wa ? `https://wa.me/${wa}${c.mensaje ? '?text=' + encodeURIComponent(c.mensaje) : ''}` : '';

    const btn = $('#cBoton');
    btn.textContent = c.boton || 'Hablemos de tu proyecto';
    btn.append(icono('flecha'));
    btn.hidden = false;
    btn.removeAttribute('target');
    if (waUrl) { btn.href = waUrl; btn.target = '_blank'; btn.rel = 'noopener'; }
    else if (email) btn.href = 'mailto:' + email;
    else if (ig) { btn.href = 'https://www.instagram.com/' + ig; btn.target = '_blank'; btn.rel = 'noopener'; }
    else btn.hidden = true;

    const links = $('#cLinks');
    links.textContent = '';
    if (waUrl) links.append(h('li', null, h('a', { href: waUrl, target: '_blank', rel: 'noopener' }, icono('wa'), 'WhatsApp')));
    if (email) links.append(h('li', null, h('a', { href: 'mailto:' + email }, icono('mail'), email)));
    if (ig) links.append(h('li', null, h('a', { href: 'https://www.instagram.com/' + ig, target: '_blank', rel: 'noopener' }, icono('ig'), '@' + ig)));
    links.hidden = !links.children.length;
  }

  /* ---------- Visor (lightbox) ---------- */
  const visor = $('#visor');
  let galeriaActual = null;

  function vacio(titulo, texto) {
    return h('div', { class: 'visor-vacio' }, h('div', null, h('strong', { text: titulo }), texto));
  }

  function galeria(fotos) {
    if (!fotos.length) return vacio('Galería en preparación', 'Las imágenes de este proyecto se añadirán pronto.');
    let idx = 0;
    const pista = h('div', { class: 'gal-pista' },
      fotos.map((f, n) => h('div', { class: 'gal-slide' }, h('img', { src: f, alt: `Imagen ${n + 1} de ${fotos.length}`, loading: n ? 'lazy' : 'eager', draggable: 'false' }))));
    const contador = h('span', { class: 'gal-contador' });
    const puntos = h('div', { class: 'gal-puntos' }, fotos.map((_, n) => h('button', { type: 'button', 'aria-label': `Ir a la imagen ${n + 1}`, onclick: () => ir(n) })));
    const cont = h('div', { class: 'galeria' + (fotos.length < 2 ? ' una' : '') },
      pista,
      h('button', { class: 'gal-flecha izq', type: 'button', 'aria-label': 'Imagen anterior', onclick: () => ir(idx - 1) }, icono('izq')),
      h('button', { class: 'gal-flecha der', type: 'button', 'aria-label': 'Imagen siguiente', onclick: () => ir(idx + 1) }, icono('der')),
      contador, puntos);
    function ir(n) {
      idx = (n + fotos.length) % fotos.length;
      pista.style.transform = `translateX(${-idx * 100}%)`;
      [...puntos.children].forEach((b, k) => b.setAttribute('aria-current', String(k === idx)));
      contador.textContent = `${idx + 1} / ${fotos.length}`;
    }
    let x0 = null;
    cont.addEventListener('pointerdown', (e) => { if (!e.target.closest('button')) x0 = e.clientX; });
    cont.addEventListener('pointerup', (e) => {
      if (x0 == null) return;
      const dx = e.clientX - x0; x0 = null;
      if (Math.abs(dx) > 40) ir(idx + (dx < 0 ? 1 : -1));
    });
    galeriaActual = { siguiente: () => ir(idx + 1), anterior: () => ir(idx - 1) };
    ir(0);
    return cont;
  }

  function abrirVisor(it, formatoSeccion) {
    const formato = it.formato || formatoSeccion || 'horizontal';
    const zona = $('#visorMedia');
    zona.textContent = '';
    galeriaActual = null;
    visor.dataset.formato = formato;

    const enlace = $('#visorEnlace');
    enlace.hidden = true;
    if (it.tipo === 'galeria') {
      zona.append(galeria(it.imagenes.map(seguro).filter(Boolean)));
    } else {
      const m = media(it.video);
      if (m && m.tipo === 'iframe') {
        zona.append(h('iframe', { src: m.src, title: it.titulo || 'Video', allow: 'autoplay; fullscreen; picture-in-picture; encrypted-media', allowfullscreen: true, referrerpolicy: 'strict-origin-when-cross-origin' }));
      } else if (m && m.tipo === 'video') {
        zona.append(h('video', { src: m.src, controls: true, autoplay: true, playsinline: true, preload: 'metadata' }));
      } else {
        const src = miniatura(it);
        zona.append(src ? h('img', { src, alt: it.titulo || '' }) : vacio('Video próximamente', 'Este proyecto se publicará muy pronto.'));
      }
      const original = seguro(it.video);
      if (m && /^https?:/i.test(original)) {
        enlace.href = original;
        enlace.textContent = `Ver en ${m.plataforma} ↗`;
        enlace.hidden = false;
      }
    }
    $('#visorMeta').textContent = [it.categoria, it.rol].filter(Boolean).join(' · ');
    $('#visorTitulo').textContent = it.titulo || 'Sin título';
    $('#visorDesc').textContent = it.descripcion || '';
    if (typeof visor.showModal === 'function') visor.showModal(); else visor.setAttribute('open', '');
  }

  function cerrarVisor() {
    if (typeof visor.close === 'function' && visor.open) visor.close(); else visor.removeAttribute('open');
  }
  if (visor) {
    visor.addEventListener('close', () => { $('#visorMedia').textContent = ''; galeriaActual = null; });
    visor.addEventListener('click', (e) => { if (e.target === visor) cerrarVisor(); });
    $('#visorCerrar').addEventListener('click', cerrarVisor);
    visor.addEventListener('keydown', (e) => {
      if (!galeriaActual) return;
      if (e.key === 'ArrowRight') galeriaActual.siguiente();
      if (e.key === 'ArrowLeft') galeriaActual.anterior();
    });
  }

  /* ---------- Recursos (bloque en el inicio, biblioteca y ficha individual) ---------- */
  const recursosVisibles = () => state.data.recursos.items.filter((r) => !r.oculto && r.slug);
  const urlRecurso = (r) => '/recursos/' + encodeURIComponent(r.slug);
  const esEnlace = (u) => /^https?:\/\//i.test(seguro(u));

  function etiquetas(r) {
    return h('span', { class: 'rec-pills' },
      r.etiqueta ? h('span', { class: 'rec-pill destacada', text: r.etiqueta }) : null,
      r.programa ? h('span', { class: 'rec-pill', text: r.programa }) : null);
  }

  function portada(r, i, clase) {
    const caja = h('span', { class: clase || 'rec-portada' });
    const src = seguro(r.portada);
    if (src) {
      const img = h('img', { src, alt: '', loading: 'lazy', decoding: 'async' });
      img.addEventListener('error', () => img.replaceWith(placeholder(i)));
      caja.append(img);
    } else {
      caja.append(placeholder(i), h('span', { class: 'rec-ph-ico' }, icono('descarga')));
    }
    return caja;
  }

  function tarjetaRecurso(r, i) {
    return h('a', { class: 'rec-card', href: urlRecurso(r) },
      portada(r, i),
      h('span', { class: 'rec-card-info' },
        etiquetas(r),
        h('span', { class: 'rec-card-titulo', text: r.titulo || 'Recurso' }),
        r.descripcion ? h('span', { class: 'rec-card-desc', text: r.descripcion }) : null,
        h('span', { class: 'rec-card-cta' }, 'Ver recurso', icono('flecha'))));
  }

  function pintarRecursosInicio() {
    const titulo = $('#riTitulo');
    if (!titulo) return;
    const rec = state.data.recursos;
    rico(titulo, rec.titulo || 'Recursos para *creadores*');
    $('#riSub').textContent = rec.subtitulo || '';
    const boton = $('#riBoton');
    boton.textContent = rec.boton || 'Explorar recursos';
    boton.append(icono('flecha'));
    const lista = $('#riLista');
    lista.textContent = '';
    recursosVisibles().slice(0, 3).forEach((r, i) => lista.append(tarjetaRecurso(r, i)));
  }

  function slugActual() {
    const m = location.pathname.match(/\/recursos\/([\w-]+)\/?$/);
    return m ? decodeURIComponent(m[1]) : new URLSearchParams(location.search).get('r');
  }

  function vistaPrevia(r) {
    const u = String(r.preview || '').trim();
    if (!u) return null;
    const m = media(u);
    if (m && m.tipo === 'iframe') {
      return h('div', { class: 'rec-video' }, h('iframe', { src: m.src.replace('autoplay=1', 'autoplay=0'), title: 'Vista previa de ' + (r.titulo || 'recurso'), allow: 'fullscreen; picture-in-picture; encrypted-media', allowfullscreen: true, loading: 'lazy', referrerpolicy: 'strict-origin-when-cross-origin' }));
    }
    if (m && m.tipo === 'video') return h('div', { class: 'rec-video' }, h('video', { src: m.src, controls: true, muted: true, loop: true, playsinline: true, preload: 'metadata' }));
    const src = seguro(u);
    return src ? h('img', { class: 'rec-preview-img', src, alt: 'Vista previa de ' + (r.titulo || 'recurso'), loading: 'lazy' }) : null;
  }

  function listaRecursos() {
    const rec = state.data.recursos;
    const titulo = h('h1');
    rico(titulo, rec.titulo || 'Recursos para *creadores*');
    document.title = 'Recursos · Wander';
    const items = recursosVisibles();
    return h('section', { class: 'rec-lista contenedor' },
      h('div', { class: 'encabezado revela' },
        h('p', { class: 'eyebrow', text: 'Biblioteca' }), titulo,
        rec.subtitulo ? h('p', { class: 'lead', text: rec.subtitulo }) : null),
      items.length
        ? h('div', { class: 'rec-rejilla' }, items.map((r, i) => {
            const w = h('div', { class: 'revela' }, tarjetaRecurso(r, i));
            w.style.transitionDelay = ((i % 3) * 70) + 'ms';
            return w;
          }))
        : h('div', { class: 'bloque-vacio rec-vacio', text: 'Muy pronto compartiré aquí presets, plantillas y herramientas.' }));
  }

  function detalleRecurso(slug) {
    const items = state.data.recursos.items;
    const i = items.findIndex((r) => r.slug === slug && (!r.oculto || editando()));
    const r = items[i];
    if (!r) {
      document.title = 'Recurso no disponible · Wander';
      return h('section', { class: 'rec-detalle contenedor rec-404' },
        h('p', { class: 'eyebrow', text: 'Recurso no disponible' }),
        h('h1', { text: 'Este recurso ya no está disponible.' }),
        h('p', { class: 'lead', text: 'Puede que el enlace haya cambiado. Echa un vistazo a la biblioteca completa.' }),
        h('a', { class: 'btn btn-primario', href: '/recursos' }, 'Ver todos los recursos', icono('flecha')));
    }
    document.title = `${r.titulo || 'Recurso'} · Recursos · Wander`;
    const descarga = esEnlace(r.enlace)
      ? h('a', { class: 'btn btn-primario btn-grande', href: seguro(r.enlace), target: '_blank', rel: 'noopener' }, r.boton || 'Descargar recurso', icono('descarga'))
      : h('span', { class: 'btn btn-contorno btn-grande rec-pronto', 'aria-disabled': 'true', text: 'Disponible muy pronto' });
    const pasos = String(r.instrucciones || '').split('\n')
      .map((s) => s.replace(/^\s*(\d+[.)]|[-•*])\s*/, '').trim()).filter(Boolean);
    const preview = vistaPrevia(r);
    const ig = limpiarIG(state.data.contacto.instagram);
    const titulo = h('h1');
    rico(titulo, r.titulo || 'Recurso');
    const lateral = [
      r.compatibilidad ? h('div', { class: 'rec-bloque' }, h('h2', { text: 'Compatibilidad' }), h('p', { text: r.compatibilidad })) : null,
      pasos.length ? h('div', { class: 'rec-bloque' }, h('h2', { text: 'Cómo usarlo' }), h('ol', { class: 'rec-pasos' }, pasos.map((s) => h('li', { text: s })))) : null
    ].filter(Boolean);

    return h('article', { class: 'rec-detalle contenedor' },
      h('a', { class: 'rec-volver', href: '/recursos' }, icono('izq'), 'Todos los recursos'),
      h('div', { class: 'rec-hero' },
        h('div', { class: 'rec-hero-media' }, portada(r, i, 'rec-portada grande')),
        h('div', { class: 'rec-hero-texto' },
          etiquetas(r), titulo,
          r.descripcion ? h('p', { class: 'lead', text: r.descripcion }) : null,
          descarga,
          esEnlace(r.enlace) ? h('p', { class: 'rec-nota', text: 'Se abrirá en una pestaña nueva. No necesitas iniciar sesión.' }) : null)),
      (preview || lateral.length) ? h('div', { class: 'rec-info' + (preview ? '' : ' sin-preview') },
        preview ? h('div', { class: 'rec-bloque rec-preview' }, h('h2', { text: 'Vista previa' }), preview) : null,
        lateral.length ? h('div', { class: 'rec-lateral' }, lateral) : null) : null,
      h('div', { class: 'rec-pie' },
        h('a', { href: '/recursos' }, icono('galeria'), 'Ver más recursos'),
        ig ? h('a', { href: 'https://www.instagram.com/' + ig, target: '_blank', rel: 'noopener' }, icono('ig'), '@' + ig) : null));
  }

  function pintarPaginaRecursos() {
    const vista = $('#vistaRecursos');
    if (!vista) return;
    vista.textContent = '';
    const slug = slugActual();
    vista.append(slug ? detalleRecurso(slug) : listaRecursos());
  }

  /* ---------- Navegación ---------- */
  const nav = $('#nav');
  const menu = $('#menu');
  const toggle = $('#navToggle');
  const onScroll = () => nav.classList.toggle('con-fondo', window.scrollY > 10);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
  function menuAbierto(v) {
    menu.classList.toggle('abierto', v);
    nav.classList.toggle('menu-abierto', v);
    toggle.setAttribute('aria-expanded', String(v));
    toggle.setAttribute('aria-label', v ? 'Cerrar menú' : 'Abrir menú');
  }
  toggle.addEventListener('click', () => menuAbierto(!menu.classList.contains('abierto')));
  menu.addEventListener('click', (e) => { if (e.target.closest('a')) menuAbierto(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') menuAbierto(false); });

  if ('IntersectionObserver' in window) {
    const enlaces = [...menu.querySelectorAll('a')];
    const obs = new IntersectionObserver((es) => es.forEach((e) => {
      if (!e.isIntersecting) return;
      enlaces.forEach((a) => a.classList.toggle('activo', a.getAttribute('href') === '#' + e.target.id));
    }), { rootMargin: '-45% 0px -50% 0px' });
    ['quien-soy', 'portafolio', 'contacto'].forEach((id) => { const s = document.getElementById(id); if (s) obs.observe(s); });
  }

  /* ---------- Timecode del visor de cámara ---------- */
  const tc = $('#camTC');
  if (tc && !reduce) {
    const t0 = performance.now();
    setInterval(() => {
      const f = Math.floor((performance.now() - t0) / 1000 * 24);
      tc.textContent = `00:${pad(Math.floor(f / 1440) % 60)}:${pad(Math.floor(f / 24) % 60)}:${pad(f % 24)}`;
    }, 1000 / 24);
  }
  $('#anio').textContent = new Date().getFullYear();

  /* ---------- Render + guardado ---------- */
  function render() {
    pintarPerfil();
    pintarPortafolio();
    pintarRecursosInicio();
    pintarPaginaRecursos();
    pintarContacto();
    revelar(document);
    primerPintado = false;
    document.dispatchEvent(new CustomEvent('wander:render'));
  }

  /* Borrador del dueño: se guarda en este navegador hasta que pulsa "Publicar" */
  function guardar() {
    let ok = true;
    state.pendiente = true;
    try { localStorage.setItem(KEY, JSON.stringify(state.data)); } catch (e) { ok = false; }
    render();
    document.dispatchEvent(new CustomEvent('wander:guardado', { detail: { ok } }));
    return ok;
  }
  let temporizador;
  function guardarSuave() {
    clearTimeout(temporizador);
    temporizador = setTimeout(guardar, 250);
  }
  function entrarEdicion() {
    let borrador = null;
    try { const s = localStorage.getItem(KEY); if (s) borrador = normalizar(JSON.parse(s)); } catch (e) { /* nada */ }
    state.data = borrador || clone(state.publicado);
    state.pendiente = !!borrador;
    render();
  }
  function salirEdicion() {
    clearTimeout(temporizador);
    state.data = clone(state.publicado);
    render();
  }
  function descartar() {
    clearTimeout(temporizador);
    try { localStorage.removeItem(KEY); } catch (e) { /* nada */ }
    state.data = clone(state.publicado);
    state.pendiente = false;
    render();
  }
  function marcarPublicado() {
    clearTimeout(temporizador);
    state.publicado = normalizar(clone(state.data));
    state.pendiente = false;
    try {
      localStorage.removeItem(KEY);
      localStorage.setItem(KEY_PUBLICADO, JSON.stringify(state.publicado));
    } catch (e) { /* nada */ }
  }
  function reemplazar(nuevo) {
    state.data = normalizar(nuevo);
    return guardar();
  }

  const listo = cargarPublicado().then(render);

  window.Wander = {
    state, render, guardar, guardarSuave, descartar, reemplazar, normalizar, entrarEdicion, salirEdicion, marcarPublicado, listo, KEY,
    util: { h, icono, seguro, rico, media, miniatura, uid, pad, itemsVisibles }
  };
})();
