/* Contenido publicado de la web de WANDER.
   No hace falta editar este archivo a mano: abre la página con #editar al final
   de la dirección (ej. tudominio.com/#editar), haz los cambios y usa
   "Publicar → Descargar contenido.js" para reemplazar este archivo. */
window.WANDER_CONTENIDO = {
  "perfil": {
    "nombre": "Wander",
    "rol": "Video editor & filmmaker",
    "titular": "Transformo ideas en *historias visuales* que destacan.",
    "subtitulo": "Edición de video, producción audiovisual y motion graphics para marcas, empresas y creadores.",
    "saludo": "Hola, soy *Wander.*",
    "bio": "Soy Wander, editor de video y filmmaker. Me especializo en convertir ideas en piezas audiovisuales que comuniquen con intención, combinando edición, producción y diseño en movimiento.",
    "foto": "media/wander-retrato.webp",
    "especialidades": [
      { "titulo": "Edición de video", "texto": "Edición de contenido corporativo, comercial y digital con atención al ritmo, la narrativa y el detalle." },
      { "titulo": "Producción audiovisual", "texto": "Grabación y realización de contenido visual para marcas, empresas y proyectos creativos." },
      { "titulo": "Contenido para redes", "texto": "Reels y piezas verticales diseñadas para comunicar con claridad y captar la atención." },
      { "titulo": "Motion Graphics", "texto": "Animaciones, títulos y elementos gráficos que dan personalidad a cada proyecto." }
    ]
  },
  "portafolio": {
    "titulo": "Proyectos *seleccionados*",
    "subtitulo": "Una selección de trabajos donde la creatividad, la técnica y la narrativa se encuentran.",
    "secciones": [
      {
        "id": "destacados",
        "titulo": "Trabajo destacado",
        "descripcion": "Seis proyectos. Una selección de lo mejor.",
        "tipo": "cuadricula",
        "formato": "horizontal",
        "limite": "6",
        "oculto": false,
        "items": [
          { "id": "p1", "titulo": "Proyecto destacado 01", "categoria": "Edición · Narrativa", "rol": "", "descripcion": "Describe aquí el proyecto, la idea y cuál fue tu participación.", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false },
          { "id": "p2", "titulo": "Proyecto destacado 02", "categoria": "Edición · Narrativa", "rol": "", "descripcion": "Describe aquí el proyecto, la idea y cuál fue tu participación.", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false },
          { "id": "p3", "titulo": "Proyecto destacado 03", "categoria": "Filmmaking", "rol": "", "descripcion": "Describe aquí el proyecto, la idea y cuál fue tu participación.", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false },
          { "id": "p4", "titulo": "Proyecto destacado 04", "categoria": "Filmmaking", "rol": "", "descripcion": "Describe aquí el proyecto, la idea y cuál fue tu participación.", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false },
          { "id": "p5", "titulo": "Proyecto destacado 05", "categoria": "Motion Graphics", "rol": "", "descripcion": "Describe aquí el proyecto, la idea y cuál fue tu participación.", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false },
          { "id": "p6", "titulo": "Proyecto destacado 06", "categoria": "Comercial", "rol": "", "descripcion": "Describe aquí el proyecto, la idea y cuál fue tu participación.", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false }
        ]
      },
      {
        "id": "reels",
        "titulo": "Reels y contenido *vertical*",
        "descripcion": "Piezas verticales pensadas para captar la atención en redes.",
        "tipo": "carrusel",
        "formato": "vertical",
        "oculto": false,
        "items": [
          { "id": "r1", "titulo": "Reel 01", "categoria": "Contenido para redes", "rol": "", "descripcion": "", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false },
          { "id": "r2", "titulo": "Reel 02", "categoria": "Contenido para redes", "rol": "", "descripcion": "", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false },
          { "id": "r3", "titulo": "Reel 03", "categoria": "Contenido para redes", "rol": "", "descripcion": "", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false },
          { "id": "r4", "titulo": "Reel 04", "categoria": "Contenido para redes", "rol": "", "descripcion": "", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false },
          { "id": "r5", "titulo": "Reel 05", "categoria": "Contenido para redes", "rol": "", "descripcion": "", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false },
          { "id": "r6", "titulo": "Reel 06", "categoria": "Contenido para redes", "rol": "", "descripcion": "", "tipo": "video", "video": "", "imagenes": [], "miniatura": "", "formato": "", "oculto": false }
        ]
      }
    ]
  },
  "recursos": {
    "titulo": "Recursos para *creadores*",
    "subtitulo": "Presets, plantillas y herramientas que comparto para ayudarte a crear y editar con más facilidad.",
    "boton": "Explorar recursos",
    "items": [
      {
        "id": "rc1",
        "slug": "carrusel-ae",
        "titulo": "Carrusel animado AE",
        "etiqueta": "Gratis",
        "programa": "After Effects",
        "descripcion": "Proyecto editable para crear un carrusel con seis elementos. Incluye instrucciones y requisitos.",
        "portada": "",
        "preview": "",
        "compatibilidad": "After Effects. Indica aquí la versión mínima y si requiere algún plugin.",
        "instrucciones": "Descarga y descomprime el archivo.\nAbre el proyecto en After Effects.\nReemplaza los seis elementos por tus imágenes o videos.\nExporta y listo.",
        "enlace": "",
        "boton": "Descargar recurso",
        "oculto": false
      }
    ]
  },
  "contacto": {
    "titulo": "¿Tienes un proyecto *en mente?*",
    "texto": "Cuéntame tu idea y trabajemos en algo que destaque.",
    "boton": "Hablemos de tu proyecto",
    "whatsapp": "",
    "mensaje": "Hola Wander, vi tu portafolio y me gustaría hablar sobre un proyecto.",
    "email": "",
    "instagram": ""
  }
};
