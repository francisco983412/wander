/* WANDER · Editor visual
   Se abre agregando #editar a la dirección. El dueño entra con su contraseña, edita
   (los cambios se guardan como borrador en su navegador) y al pulsar "Publicar" se
   guardan en el servidor (/api) y todos los visitantes los ven al momento.
   Si el hosting no tiene servidor, funciona en modo manual (descargar contenido.js). */
(() => {
  'use strict';
  const W = window.Wander;
  if (!W) return;
  const { h, uid, media, miniatura, seguro, pad } = W.util;
  const datos = () => W.state.data;

  let panel = null, cuerpo = null, estado = null, login = null;

  /* ---------- Sesión del dueño y API ---------- */
  const TOKEN = 'wander-token';
  const token = {
    leer() {
      try {
        const t = localStorage.getItem(TOKEN) || '';
        return Number(t.split('.')[0]) > Date.now() + 60000 ? t : '';
      } catch (e) { return ''; }
    },
    poner(t) { try { localStorage.setItem(TOKEN, t); } catch (e) { /* nada */ } },
    quitar() { try { localStorage.removeItem(TOKEN); } catch (e) { /* nada */ } }
  };
  const conServidor = () => W.state.servidor;

  async function api(ruta, opciones = {}) {
    const headers = Object.assign({}, opciones.headers);
    const t = token.leer();
    if (t) headers.Authorization = 'Bearer ' + t;
    const r = await fetch('/api/' + ruta, Object.assign({}, opciones, { headers, cache: 'no-store' }));
    let cuerpoResp = null;
    try { cuerpoResp = await r.json(); } catch (e) { /* sin cuerpo JSON */ }
    if (r.status === 401 && ruta !== 'login') {
      token.quitar();
      aviso('Tu sesión expiró. Vuelve a entrar.', true);
      mostrarLogin();
    }
    if (!r.ok) throw new Error((cuerpoResp && cuerpoResp.error) || 'Error ' + r.status);
    return cuerpoResp;
  }
  let pestana = 'portafolio';
  let itemAbierto = null;
  let seccionAbierta = null;
  let recursoAbierto = null;

  const ICO = {
    arriba: '<path d="m18 15-6-6-6 6"/>',
    abajo: '<path d="m6 9 6 6 6-6"/>',
    ojo: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    ojoNo: '<path d="M3 3l18 18M10.6 5.1A10.6 10.6 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4M6.6 6.6C3.8 8.4 2 12 2 12s3.6 7 10 7a9.7 9.7 0 0 0 5.4-1.6M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
    lapiz: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
    ajustes: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
    basura: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
    mas: '<path d="M12 5v14M5 12h14"/>',
    cerrar: '<path d="M6 6l12 12M18 6 6 18"/>',
    min: '<path d="m6 9 6 6 6-6"/>',
    subir: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
    bajar: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
    rejilla: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    carrusel: '<rect x="7" y="5" width="10" height="14" rx="2"/><path d="M3 7v10M21 7v10"/>',
    lapizPagina: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>'
  };
  function ico(n) {
    const s = document.createElement('span');
    s.className = 'ico';
    s.setAttribute('aria-hidden', 'true');
    s.innerHTML = '<svg viewBox="0 0 24 24">' + (ICO[n] || '') + '</svg>';
    return s;
  }
  const btnIco = (n, label, fn, extra) => h('button', { type: 'button', class: 'ed-ico' + (extra ? ' ' + extra : ''), title: label, 'aria-label': label, onclick: fn }, ico(n));
  const btn = (texto, fn, clase, icono) => h('button', { type: 'button', class: 'ed-btn ' + (clase || ''), onclick: fn }, icono ? ico(icono) : null, texto);

  function mover(arr, i, d) {
    const j = i + d;
    if (j < 0 || j >= arr.length) return false;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    return true;
  }

  /* ---------- Campos ---------- */
  function campo(etiqueta, obj, clave, op = {}) {
    let control;
    if (op.opciones) {
      control = h('select', null, op.opciones.map(([v, t]) => h('option', { value: v, text: t })));
      control.value = obj[clave] != null ? obj[clave] : op.opciones[0][0];
      control.addEventListener('change', () => {
        obj[clave] = control.value;
        W.guardar();
        if (op.repintar) pintar();
      });
    } else {
      control = op.area
        ? h('textarea', { rows: op.filas || 3, placeholder: op.placeholder })
        : h('input', { type: op.tipo || 'text', placeholder: op.placeholder, inputmode: op.inputmode });
      control.value = obj[clave] != null ? obj[clave] : '';
      control.addEventListener('input', () => {
        obj[clave] = control.value;
        W.guardarSuave();
        if (op.alCambiar) op.alCambiar(control.value);
      });
    }
    return h('label', { class: 'ed-campo' }, h('span', { text: etiqueta }), control, op.ayuda ? h('small', { text: op.ayuda }) : null);
  }

  function comprimir(file, max = 1600, calidad = 0.82) {
    return new Promise((ok, mal) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
        const c = document.createElement('canvas');
        c.width = Math.round(img.naturalWidth * s);
        c.height = Math.round(img.naturalHeight * s);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        c.toBlob((b) => (b ? ok(b) : mal(new Error('No se pudo comprimir'))), 'image/jpeg', calidad);
      };
      img.onerror = () => { URL.revokeObjectURL(url); mal(new Error('Imagen no válida')); };
      img.src = url;
    });
  }

  const aDataUrl = (blob) => new Promise((ok, mal) => {
    const fr = new FileReader();
    fr.onload = () => ok(fr.result);
    fr.onerror = mal;
    fr.readAsDataURL(blob);
  });

  /* Con servidor: la imagen se sube y se guarda su dirección. Sin servidor: va incrustada. */
  async function prepararImagen(file) {
    const blob = await comprimir(file);
    if (conServidor() && token.leer()) {
      const r = await api('media', { method: 'POST', headers: { 'Content-Type': 'image/jpeg' }, body: blob });
      return r.url;
    }
    return aDataUrl(blob);
  }

  function elegirArchivos(multiple, alElegir) {
    const input = h('input', { type: 'file', accept: 'image/*', multiple: multiple || null });
    input.addEventListener('change', async () => {
      const files = [...input.files];
      if (!files.length) return;
      aviso('Subiendo imagen' + (files.length > 1 ? 'es' : '') + '…');
      const res = [];
      for (const f of files) {
        try { res.push(await prepararImagen(f)); } catch (e) { aviso('No se pudo subir ' + f.name + (e.message ? ': ' + e.message : ''), true); }
      }
      if (res.length) { alElegir(res); aviso(res.length > 1 ? res.length + ' imágenes listas' : 'Imagen lista'); }
    });
    input.click();
  }

  function campoImagen(etiqueta, obj, clave, ayuda) {
    const vista = h('div', { class: 'ed-img-vista' });
    const url = h('input', { type: 'text', placeholder: 'https://…  o  media/archivo.jpg' });
    const esData = () => /^data:/.test(obj[clave] || '');
    const refrescar = () => {
      vista.textContent = '';
      const src = seguro(obj[clave]);
      if (media(obj[clave])) vista.append(h('span', { text: '▶ Video ' + media(obj[clave]).plataforma }));
      else if (src) vista.append(h('img', { src, alt: '' }));
      else vista.append(h('span', { text: 'Sin imagen' }));
      url.value = esData() ? '' : (obj[clave] || '');
      url.placeholder = esData() ? 'Imagen subida desde tu equipo ✓' : 'https://…  o  media/archivo.jpg';
    };
    url.addEventListener('input', () => { obj[clave] = url.value.trim(); W.guardarSuave(); clearTimeout(url._t); url._t = setTimeout(refrescar, 400); });
    refrescar();
    return h('div', { class: 'ed-campo' },
      h('span', { text: etiqueta }),
      h('div', { class: 'ed-img' }, vista,
        h('div', { class: 'ed-img-ctrl' }, url,
          h('div', { class: 'ed-fila' },
            btn('Subir imagen', () => elegirArchivos(false, ([d]) => { obj[clave] = d; if (W.guardar()) refrescar(); }), 'ed-btn-sec', 'subir'),
            btn('Quitar', () => { obj[clave] = ''; W.guardar(); refrescar(); }, 'ed-btn-txt')))),
      ayuda ? h('small', { text: ayuda }) : null);
  }

  /* ---------- Pestaña: Perfil ---------- */
  function pestanaPerfil() {
    const p = datos().perfil;
    const lista = h('div', { class: 'ed-lista' });
    p.especialidades.forEach((e, i) => {
      lista.append(h('div', { class: 'ed-tarjeta' },
        h('div', { class: 'ed-tarjeta-cab' },
          h('strong', { text: pad(i + 1) + ' · ' + (e.titulo || 'Especialidad') }),
          h('div', { class: 'ed-acciones' },
            btnIco('arriba', 'Subir', () => { if (mover(p.especialidades, i, -1)) { W.guardar(); pintar(); } }),
            btnIco('abajo', 'Bajar', () => { if (mover(p.especialidades, i, 1)) { W.guardar(); pintar(); } }),
            btnIco('basura', 'Eliminar', () => { if (confirm('¿Eliminar esta especialidad?')) { p.especialidades.splice(i, 1); W.guardar(); pintar(); } }, 'peligro'))),
        campo('Título', e, 'titulo'),
        campo('Descripción', e, 'texto', { area: true, filas: 2 })));
    });
    return [
      h('h4', { text: 'Portada' }),
      campo('Texto pequeño superior', p, 'rol', { placeholder: 'Video editor & filmmaker' }),
      campo('Titular', p, 'titular', { area: true, filas: 2, ayuda: 'Pon *entre asteriscos* las palabras que quieras en naranja.' }),
      campo('Subtítulo', p, 'subtitulo', { area: true, filas: 2 }),
      campoImagen('Tu foto (retrato)', p, 'foto', 'Recomendado: vertical, buena luz. Si no hay foto se muestra tu inicial.'),
      h('h4', { text: 'Quién soy' }),
      campo('Nombre', p, 'nombre'),
      campo('Título de la sección', p, 'saludo', { ayuda: 'También acepta *asteriscos* para resaltar.' }),
      campo('Biografía', p, 'bio', { area: true, filas: 5, ayuda: 'Deja una línea en blanco para separar párrafos.' }),
      h('h4', { text: 'Especialidades' }),
      lista,
      btn('Agregar especialidad', () => { p.especialidades.push({ titulo: 'Nueva especialidad', texto: '' }); W.guardar(); pintar(); }, 'ed-btn-sec ed-ancho', 'mas')
    ];
  }

  /* ---------- Pestaña: Portafolio ---------- */
  function nuevoItem() {
    return { id: uid(), titulo: 'Nuevo proyecto', categoria: '', rol: '', descripcion: '', tipo: 'video', video: '', imagenes: [], miniatura: '', formato: '', oculto: false };
  }

  function formItem(sec, it) {
    const secs = datos().portafolio.secciones;
    const detectado = h('small', { class: 'ed-detectado' });
    const detectar = (v) => {
      const m = media(v);
      detectado.textContent = !v ? 'Pega el enlace de YouTube, Vimeo, Google Drive, Instagram, TikTok o un .mp4 en la carpeta media/.'
        : m ? '✓ Reconocido: ' + m.plataforma + (m.thumb ? ' (miniatura automática)' : '')
        : '⚠ No reconozco este enlace. Revisa que sea un enlace público.';
      detectado.classList.toggle('mal', !!v && !m);
    };
    detectar(it.video);

    const partes = [
      campo('Título', it, 'titulo'),
      h('div', { class: 'ed-dos' }, campo('Categoría', it, 'categoria', { placeholder: 'Ej. Filmmaking' }), campo('Tu rol', it, 'rol', { placeholder: 'Ej. Edición y color' })),
      campo('Descripción', it, 'descripcion', { area: true, filas: 3 }),
      campo('Tipo de contenido', it, 'tipo', { opciones: [['video', 'Video'], ['galeria', 'Galería de imágenes (carrusel)']], repintar: true })
    ];

    if (it.tipo === 'galeria') {
      const fotos = h('div', { class: 'ed-fotos' });
      it.imagenes.forEach((src, i) => {
        fotos.append(h('div', { class: 'ed-foto' },
          seguro(src) ? h('img', { src: seguro(src), alt: '' }) : h('span', { text: '?' }),
          h('div', { class: 'ed-foto-acc' },
            btnIco('arriba', 'Mover antes', () => { if (mover(it.imagenes, i, -1)) { W.guardar(); pintar(); } }),
            btnIco('abajo', 'Mover después', () => { if (mover(it.imagenes, i, 1)) { W.guardar(); pintar(); } }),
            btnIco('basura', 'Quitar', () => { it.imagenes.splice(i, 1); W.guardar(); pintar(); }, 'peligro'))));
      });
      partes.push(h('div', { class: 'ed-campo' }, h('span', { text: `Imágenes de la galería (${it.imagenes.length})` }), fotos,
        h('div', { class: 'ed-fila' },
          btn('Subir imágenes', () => elegirArchivos(true, (arr) => { it.imagenes.push(...arr); if (!W.guardar()) it.imagenes.splice(-arr.length); pintar(); }), 'ed-btn-sec', 'subir'),
          btn('Agregar por enlace', () => {
            const u = prompt('Pega el enlace de la imagen (https://…) o la ruta (media/foto.jpg):');
            if (u && seguro(u)) { it.imagenes.push(u.trim()); W.guardar(); pintar(); }
          }, 'ed-btn-txt'))));
    } else {
      partes.push(h('div', null, campo('Enlace del video', it, 'video', { placeholder: 'https://youtu.be/…', alCambiar: detectar }), detectado));
    }

    partes.push(
      campoImagen('Miniatura (portada)', it, 'miniatura', it.tipo === 'galeria' ? 'Si la dejas vacía se usa la primera imagen.' : 'Si la dejas vacía se usa la de YouTube/Vimeo/Drive cuando exista.'),
      h('div', { class: 'ed-dos' },
        campo('Formato del video', it, 'formato', { opciones: [['', 'Igual que la sección'], ['horizontal', 'Horizontal 16:9'], ['vertical', 'Vertical 9:16'], ['cuadrado', 'Cuadrado 1:1']] }),
        (() => {
          const sel = h('select', null, secs.map((s) => h('option', { value: s.id, text: (s.titulo || 'Sección').replace(/\*/g, '') })));
          sel.value = sec.id;
          sel.addEventListener('change', () => {
            const destino = secs.find((s) => s.id === sel.value);
            if (!destino || destino === sec) return;
            sec.items.splice(sec.items.indexOf(it), 1);
            destino.items.push(it);
            W.guardar(); pintar();
            aviso('Proyecto movido a «' + (destino.titulo || '').replace(/\*/g, '') + '»');
          });
          return h('label', { class: 'ed-campo' }, h('span', { text: 'Sección' }), sel);
        })()),
      h('div', { class: 'ed-fila ed-fin' },
        btn('Ver en la página', () => irA(sec.id), 'ed-btn-txt'),
        btn('Listo', () => { itemAbierto = null; pintar(); }, 'ed-btn-pri')));
    return h('div', { class: 'ed-form' }, partes);
  }

  function filaItem(sec, it, i) {
    const src = miniatura(it);
    const abierto = itemAbierto === it.id;
    const fueraDelLimite = !it.oculto && !W.util.itemsVisibles(sec).includes(it);
    const estadoItem = it.oculto ? ' · oculto' : fueraDelLimite ? ' · no se ve (pasa del límite)' : '';
    return h('div', { class: 'ed-item' + (it.oculto || fueraDelLimite ? ' oculto' : '') + (abierto ? ' abierto' : '') },
      h('div', { class: 'ed-item-cab' },
        h('button', { type: 'button', class: 'ed-item-nombre', onclick: () => { itemAbierto = abierto ? null : it.id; pintar(); } },
          h('span', { class: 'ed-mini' }, src ? h('img', { src, alt: '' }) : null),
          h('span', { class: 'ed-item-txt' },
            h('strong', { text: pad(i + 1) + ' · ' + (it.titulo || 'Sin título') }),
            h('small', { text: (it.tipo === 'galeria' ? 'Galería · ' + it.imagenes.length + ' img' : (media(it.video) || {}).plataforma || 'Sin video') + estadoItem }))),
        h('div', { class: 'ed-acciones' },
          btnIco('arriba', 'Subir', () => { if (mover(sec.items, i, -1)) { W.guardar(); pintar(); } }),
          btnIco('abajo', 'Bajar', () => { if (mover(sec.items, i, 1)) { W.guardar(); pintar(); } }),
          btnIco(it.oculto ? 'ojoNo' : 'ojo', it.oculto ? 'Mostrar' : 'Ocultar', () => { it.oculto = !it.oculto; W.guardar(); pintar(); }),
          btnIco('lapiz', 'Editar', () => { itemAbierto = abierto ? null : it.id; pintar(); }),
          btnIco('basura', 'Eliminar', () => {
            if (!confirm('¿Eliminar «' + (it.titulo || 'este proyecto') + '»?')) return;
            sec.items.splice(i, 1); W.guardar(); pintar();
          }, 'peligro'))),
      abierto ? formItem(sec, it) : null);
  }

  function tarjetaSeccion(sec, si) {
    const secs = datos().portafolio.secciones;
    const ajustes = seccionAbierta === sec.id;
    const visibles = W.util.itemsVisibles(sec).length;
    const limite = parseInt(sec.limite, 10) > 0 ? ' (máx. ' + parseInt(sec.limite, 10) + ')' : '';
    const titulo = (sec.titulo || 'Sección sin título').replace(/\*/g, '');
    return h('div', { class: 'ed-sec' + (sec.oculto ? ' oculto' : '') },
      h('div', { class: 'ed-sec-cab' },
        h('span', { class: 'ed-sec-ico' }, ico(sec.tipo === 'carrusel' ? 'carrusel' : 'rejilla')),
        h('div', { class: 'ed-sec-txt' },
          h('strong', { text: titulo }),
          h('small', { text: (sec.tipo === 'carrusel' ? 'Carrusel' : 'Cuadrícula') + ' · ' + ({ horizontal: '16:9', vertical: '9:16', cuadrado: '1:1' }[sec.formato] || '16:9') + ' · ' + visibles + ' visible' + (visibles === 1 ? '' : 's') + limite + (sec.oculto ? ' · sección oculta' : '') })),
        h('div', { class: 'ed-acciones' },
          btnIco('arriba', 'Subir sección', () => { if (mover(secs, si, -1)) { W.guardar(); pintar(); } }),
          btnIco('abajo', 'Bajar sección', () => { if (mover(secs, si, 1)) { W.guardar(); pintar(); } }),
          btnIco(sec.oculto ? 'ojoNo' : 'ojo', sec.oculto ? 'Mostrar sección' : 'Ocultar sección', () => { sec.oculto = !sec.oculto; W.guardar(); pintar(); }),
          btnIco('ajustes', 'Ajustes de la sección', () => { seccionAbierta = ajustes ? null : sec.id; pintar(); }, ajustes ? 'activo' : ''),
          btnIco('basura', 'Eliminar sección', () => {
            if (!confirm('¿Eliminar la sección «' + titulo + '» y sus ' + sec.items.length + ' proyectos?')) return;
            secs.splice(si, 1); W.guardar(); pintar();
          }, 'peligro'))),
      ajustes ? h('div', { class: 'ed-form ed-form-sec' },
        campo('Título de la sección', sec, 'titulo', { ayuda: 'Acepta *asteriscos* para resaltar en naranja.' }),
        campo('Descripción', sec, 'descripcion', { area: true, filas: 2 }),
        h('div', { class: 'ed-dos' },
          campo('Diseño', sec, 'tipo', { opciones: [['cuadricula', 'Cuadrícula'], ['carrusel', 'Carrusel deslizable']], repintar: true }),
          campo('Formato de miniaturas', sec, 'formato', { opciones: [['horizontal', 'Horizontal 16:9'], ['vertical', 'Vertical 9:16'], ['cuadrado', 'Cuadrado 1:1']], repintar: true })),
        campo('Máximo de proyectos que se ven', sec, 'limite', {
          opciones: [['', 'Sin límite'], ['3', '3'], ['4', '4'], ['6', '6'], ['8', '8'], ['9', '9'], ['12', '12']],
          repintar: true,
          ayuda: 'Se muestran los primeros de la lista. Los demás quedan guardados: súbelos con las flechas para cambiarlos por los actuales.'
        }),
        h('div', { class: 'ed-fila ed-fin' }, btn('Listo', () => { seccionAbierta = null; pintar(); }, 'ed-btn-pri'))) : null,
      h('div', { class: 'ed-items' }, sec.items.map((it, i) => filaItem(sec, it, i))),
      btn('Agregar proyecto', () => {
        const it = nuevoItem();
        sec.items.push(it);
        itemAbierto = it.id;
        W.guardar(); pintar();
        irA(sec.id);
      }, 'ed-btn-sec ed-ancho', 'mas'));
  }

  function pestanaPortafolio() {
    const port = datos().portafolio;
    const nuevaSeccion = (tipo) => {
      const sec = { id: uid(), titulo: tipo === 'carrusel' ? 'Nuevo carrusel' : 'Nueva sección', descripcion: '', tipo, formato: 'horizontal', oculto: false, items: [] };
      port.secciones.push(sec);
      seccionAbierta = sec.id;
      W.guardar(); pintar();
      setTimeout(() => irA(sec.id), 60);
    };
    return [
      h('h4', { text: 'Encabezado del portafolio' }),
      campo('Título', port, 'titulo', { ayuda: 'Acepta *asteriscos* para resaltar en naranja.' }),
      campo('Subtítulo', port, 'subtitulo', { area: true, filas: 2 }),
      h('h4', { text: 'Secciones y proyectos' }),
      h('p', { class: 'ed-nota', text: 'Cada sección puede ser una cuadrícula o un carrusel. Usa las flechas para ordenar, el ojo para ocultar sin borrar y el lápiz para editar.' }),
      h('div', { class: 'ed-secs' }, port.secciones.map(tarjetaSeccion)),
      h('div', { class: 'ed-dos' },
        btn('Nueva cuadrícula', () => nuevaSeccion('cuadricula'), 'ed-btn-sec', 'rejilla'),
        btn('Nuevo carrusel', () => nuevaSeccion('carrusel'), 'ed-btn-sec', 'carrusel'))
    ];
  }

  /* ---------- Pestaña: Recursos ---------- */
  const slugsAutomaticos = new Set(); // fichas nuevas: el enlace sigue al título hasta que lo edites
  function slugDe(texto) {
    return String(texto || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
      .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'recurso';
  }
  function slugUnico(base, propio) {
    const usados = new Set(datos().recursos.items.filter((r) => r !== propio).map((r) => r.slug));
    let s = base;
    for (let n = 2; usados.has(s); n++) s = `${base}-${n}`;
    return s;
  }
  const enlacePublico = (r) => location.origin + '/recursos/' + r.slug;

  function copiar(texto) {
    const ok = () => aviso('Enlace copiado. Pégalo en ManyChat.');
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(texto).then(ok, () => prompt('Copia el enlace:', texto));
    else prompt('Copia el enlace:', texto);
  }

  function irARecurso(r) {
    W.guardar();
    location.href = '/recursos/' + encodeURIComponent(r.slug) + '#editar';
  }

  function formRecurso(r) {
    const enlace = h('code', { class: 'ed-enlace', text: enlacePublico(r) });
    const slugInput = h('input', { type: 'text', spellcheck: 'false', 'aria-label': 'Enlace de la ficha' });
    slugInput.value = r.slug;
    /* si estamos viendo esta ficha, la dirección de la página sigue al nuevo enlace */
    let slugEnUrl = r.slug;
    const sincronizarUrl = () => {
      if (r.slug && decodeURIComponent(location.pathname) === '/recursos/' + slugEnUrl) {
        history.replaceState(null, '', '/recursos/' + r.slug + location.hash);
        slugEnUrl = r.slug;
      }
    };
    const fijarSlug = (valor) => {
      r.slug = slugUnico(slugDe(valor), r);
      slugInput.value = r.slug;
      enlace.textContent = enlacePublico(r);
      sincronizarUrl();
    };
    slugInput.addEventListener('input', () => {
      slugsAutomaticos.delete(r.id);
      r.slug = slugInput.value.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9-]+/g, '-');
      enlace.textContent = enlacePublico(r);
      sincronizarUrl();
      W.guardarSuave();
    });
    slugInput.addEventListener('change', () => { fijarSlug(slugInput.value || r.titulo); W.guardar(); });

    const avisoEnlace = h('small', { class: 'ed-detectado' });
    const revisarEnlace = (v) => {
      v = String(v || '').trim();
      avisoEnlace.classList.toggle('mal', !!v && !/^https?:\/\//i.test(v));
      avisoEnlace.textContent = !v ? 'Mientras esté vacío, el botón dirá «Disponible muy pronto».'
        : !/^https?:\/\//i.test(v) ? '⚠ Debe empezar por https://'
        : /drive\.google\.com|docs\.google\.com/i.test(v) ? '✓ Google Drive. Revisa que el acceso sea «Cualquier persona con el enlace».'
        : '✓ Enlace listo.';
    };
    revisarEnlace(r.enlace);

    return h('div', { class: 'ed-form' },
      campo('Nombre del recurso', r, 'titulo', {
        alCambiar: (v) => { if (slugsAutomaticos.has(r.id)) fijarSlug(v); }
      }),
      h('div', { class: 'ed-dos' },
        campo('Etiqueta', r, 'etiqueta', { placeholder: 'Gratis' }),
        campo('Programa', r, 'programa', { placeholder: 'After Effects' })),
      campo('Descripción breve', r, 'descripcion', { area: true, filas: 3, ayuda: 'Qué hace y para quién es.' }),
      campoImagen('Portada', r, 'portada', 'Recomendado: horizontal (4:3 o 16:10), con identidad WANDER.'),
      campoImagen('Vista previa (opcional)', r, 'preview', 'Una imagen o GIF, o pega un enlace de YouTube/Vimeo/Drive para un video corto.'),
      campo('Compatibilidad', r, 'compatibilidad', { area: true, filas: 2, placeholder: 'After Effects 2022 o superior. No requiere plugins.' }),
      campo('Instrucciones rápidas', r, 'instrucciones', { area: true, filas: 4, ayuda: 'Un paso por línea.' }),
      h('div', null, campo('Enlace de descarga (Google Drive u otro)', r, 'enlace', { placeholder: 'https://drive.google.com/…', alCambiar: revisarEnlace }), avisoEnlace),
      campo('Texto del botón', r, 'boton', { placeholder: 'Descargar recurso' }),
      h('div', { class: 'ed-campo' },
        h('span', { text: 'Enlace de la ficha (para ManyChat)' }),
        h('div', { class: 'ed-slug' }, h('span', { text: '/recursos/' }), slugInput),
        enlace,
        h('div', { class: 'ed-fila' },
          btn('Copiar enlace', () => copiar(enlacePublico(r)), 'ed-btn-sec', 'subir'),
          btn('Ver la ficha', () => irARecurso(r), 'ed-btn-txt')),
        h('small', { text: 'Si cambias el enlace después de compartirlo, el anterior dejará de funcionar.' })),
      h('div', { class: 'ed-fila ed-fin' }, btn('Listo', () => { recursoAbierto = null; pintar(); }, 'ed-btn-pri')));
  }

  function filaRecurso(r, i) {
    const items = datos().recursos.items;
    const abierto = recursoAbierto === r.id;
    const src = seguro(r.portada);
    const abrirCerrar = () => { recursoAbierto = abierto ? null : r.id; pintar(); };
    return h('div', { class: 'ed-item' + (r.oculto ? ' oculto' : '') + (abierto ? ' abierto' : '') },
      h('div', { class: 'ed-item-cab' },
        h('button', { type: 'button', class: 'ed-item-nombre', onclick: abrirCerrar },
          h('span', { class: 'ed-mini' }, src ? h('img', { src, alt: '' }) : null),
          h('span', { class: 'ed-item-txt' },
            h('strong', { text: r.titulo || 'Sin nombre' }),
            h('small', { text: '/recursos/' + r.slug + (r.oculto ? ' · oculto' : !/^https?:/i.test(r.enlace || '') ? ' · sin enlace de descarga' : '') }))),
        h('div', { class: 'ed-acciones' },
          btnIco('arriba', 'Subir', () => { if (mover(items, i, -1)) { W.guardar(); pintar(); } }),
          btnIco('abajo', 'Bajar', () => { if (mover(items, i, 1)) { W.guardar(); pintar(); } }),
          btnIco(r.oculto ? 'ojoNo' : 'ojo', r.oculto ? 'Mostrar' : 'Ocultar', () => { r.oculto = !r.oculto; W.guardar(); pintar(); }),
          btnIco('lapiz', 'Editar', abrirCerrar),
          btnIco('basura', 'Eliminar', () => {
            if (!confirm('¿Eliminar «' + (r.titulo || 'este recurso') + '»? Su enlace dejará de funcionar.')) return;
            items.splice(i, 1); W.guardar(); pintar();
          }, 'peligro'))),
      abierto ? formRecurso(r) : null);
  }

  function pestanaRecursos() {
    const rec = datos().recursos;
    return [
      h('h4', { text: 'Biblioteca de recursos' }),
      campo('Título', rec, 'titulo', { ayuda: 'Acepta *asteriscos* para resaltar en naranja.' }),
      campo('Subtítulo', rec, 'subtitulo', { area: true, filas: 2 }),
      campo('Texto del botón en el inicio', rec, 'boton', { placeholder: 'Explorar recursos' }),
      h('h4', { text: 'Fichas' }),
      h('p', { class: 'ed-nota', text: 'Cada ficha tiene su propio enlace para enviarlo por ManyChat. En el inicio se muestran las 3 primeras de la lista.' }),
      h('div', { class: 'ed-items' }, rec.items.map(filaRecurso)),
      btn('Nuevo recurso', () => {
        const r = { id: uid(), slug: '', titulo: 'Nuevo recurso', etiqueta: 'Gratis', programa: '', descripcion: '', portada: '', preview: '', compatibilidad: '', instrucciones: '', enlace: '', boton: 'Descargar recurso', oculto: false };
        r.slug = slugUnico(slugDe(r.titulo), r);
        slugsAutomaticos.add(r.id);
        rec.items.unshift(r);
        recursoAbierto = r.id;
        W.guardar(); pintar();
        cuerpo.scrollTop = 0;
      }, 'ed-btn-sec ed-ancho', 'mas'),
      btn('Ver la biblioteca', () => { W.guardar(); location.href = '/recursos#editar'; }, 'ed-btn-txt ed-ancho')
    ];
  }

  /* ---------- Pestaña: Contacto ---------- */
  function pestanaContacto() {
    const c = datos().contacto;
    return [
      h('h4', { text: 'Bloque de contacto' }),
      campo('Título', c, 'titulo', { ayuda: 'Acepta *asteriscos* para resaltar en naranja.' }),
      campo('Texto', c, 'texto', { area: true, filas: 2 }),
      campo('Texto del botón', c, 'boton'),
      h('h4', { text: 'Canales' }),
      campo('WhatsApp', c, 'whatsapp', { tipo: 'tel', inputmode: 'tel', placeholder: '18091234567', ayuda: 'Con código de país, solo números. Ej. 18091234567' }),
      campo('Mensaje automático de WhatsApp', c, 'mensaje', { area: true, filas: 2 }),
      campo('Correo', c, 'email', { tipo: 'email', placeholder: 'hola@tudominio.com' }),
      campo('Instagram', c, 'instagram', { placeholder: '@usuario' })
    ];
  }

  /* ---------- Pestaña: Publicar ---------- */
  function tamano() {
    try { return ((localStorage.getItem(W.KEY) || '').length / 1024 / 1024).toFixed(2); } catch (e) { return '0'; }
  }
  function descargar() {
    const txt = '/* Copia de seguridad del contenido de la web de WANDER (' + new Date().toLocaleString('es') + ').\n' +
      '   Para restaurarla: Editor -> Publicar -> Importar archivo. */\nwindow.WANDER_CONTENIDO = ' + JSON.stringify(datos(), null, 2) + ';\n';
    const a = h('a', { href: URL.createObjectURL(new Blob([txt], { type: 'text/javascript' })), download: 'contenido.js' });
    document.body.append(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    aviso('Copia descargada');
  }
  function importar() {
    const input = h('input', { type: 'file', accept: '.js,.json,application/json,text/javascript' });
    input.addEventListener('change', async () => {
      const f = input.files[0];
      if (!f) return;
      try {
        let txt = await f.text();
        txt = txt.replace(/^[\s\S]*?window\.WANDER_CONTENIDO\s*=\s*/, '').replace(/;\s*$/, '');
        const obj = JSON.parse(txt);
        if (!obj || typeof obj !== 'object' || !obj.portafolio) throw new Error();
        if (!confirm('Esto reemplazará lo que estás editando con el archivo «' + f.name + '». ¿Continuar?')) return;
        W.reemplazar(obj);
        pintar();
        aviso('Contenido importado. Pulsa Publicar para que lo vean tus clientes.');
      } catch (e) { aviso('El archivo no es un contenido válido de WANDER', true); }
    });
    input.click();
  }

  let publicando = false;
  async function publicar() {
    if (publicando) return;
    if (!conServidor()) { pestana = 'publicar'; pintar(); return; }
    publicando = true;
    marcarEstado();
    try {
      datos()._actualizado = Date.now();
      await api('contenido', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(datos()) });
      W.marcarPublicado();
      aviso('¡Publicado! Tus clientes ya ven los cambios.');
    } catch (e) {
      aviso('No se pudo publicar: ' + e.message, true);
    }
    publicando = false;
    pintar();
  }

  function descartarCambios() {
    if (!confirm('¿Descartar los cambios sin publicar y volver a lo que ven tus clientes?')) return;
    W.descartar(); itemAbierto = null; seccionAbierta = null; pintar(); aviso('Cambios descartados');
  }

  function pestanaPublicar() {
    const extras = [
      h('h4', { text: 'Más opciones' }),
      h('div', { class: 'ed-dos' },
        btn('Descargar copia', descargar, 'ed-btn-sec', 'bajar'),
        btn('Importar archivo', importar, 'ed-btn-sec', 'subir'))
    ];
    if (!conServidor()) {
      return [
        h('h4', { text: 'Modo sin servidor' }),
        h('p', { class: 'ed-nota', text: 'Esta copia de la web no tiene el servidor de edición activo, así que los cambios solo se guardan en este navegador. Para publicarlos a mano: descarga contenido.js, reemplaza js/contenido.js en la carpeta de la web y vuelve a subirla.' }),
        btn('Descargar contenido.js', descargar, 'ed-btn-pri ed-ancho', 'bajar'),
        h('h4', { text: 'Más opciones' }),
        h('div', { class: 'ed-dos' },
          btn('Importar archivo', importar, 'ed-btn-sec', 'subir'),
          btn('Descartar cambios', descartarCambios, 'ed-btn-sec peligro')),
        h('p', { class: 'ed-nota', text: `Espacio usado por el borrador: ${tamano()} MB de ~5 MB.` })
      ];
    }
    const pend = W.state.pendiente;
    return [
      h('h4', { text: 'Publicar' }),
      h('div', { class: 'ed-publicar' + (pend ? ' pendiente' : '') },
        h('strong', { text: pend ? 'Tienes cambios sin publicar' : 'Todo está publicado' }),
        h('p', { text: pend
          ? 'Lo que ves en la página ahora es tu versión en edición. Tus clientes seguirán viendo la anterior hasta que publiques.'
          : 'Tus clientes están viendo exactamente lo que ves aquí.' }),
        pend ? h('div', { class: 'ed-dos' },
          btn(publicando ? 'Publicando…' : 'Publicar cambios', publicar, 'ed-btn-pri', 'subir'),
          btn('Descartar', descartarCambios, 'ed-btn-sec peligro')) : null),
      h('h4', { text: 'Cómo funciona' }),
      h('ol', { class: 'ed-pasos' },
        h('li', null, 'Edita lo que quieras en las pestañas. Se guarda solo mientras trabajas (si cierras, no se pierde).'),
        h('li', null, 'Pulsa ', h('b', { text: 'Publicar' }), ' y la web se actualiza al momento para todos.'),
        h('li', null, 'Las imágenes que subes quedan guardadas en tu web; los videos, mejor enlázalos desde YouTube, Vimeo o Drive.')),
      ...extras,
      h('h4', { text: 'Sesión' }),
      btn('Cerrar sesión', () => { token.quitar(); cerrar(); aviso('Sesión cerrada'); }, 'ed-btn-sec ed-ancho')
    ];
  }

  /* ---------- Panel ---------- */
  const PESTANAS = [['perfil', 'Quién soy'], ['portafolio', 'Portafolio'], ['recursos', 'Recursos'], ['contacto', 'Contacto'], ['publicar', 'Publicar']];

  function pintar() {
    if (!panel) return;
    const scroll = cuerpo.scrollTop;
    panel.querySelectorAll('.ed-tab').forEach((t) => t.setAttribute('aria-selected', String(t.dataset.p === pestana)));
    cuerpo.textContent = '';
    const contenido = { perfil: pestanaPerfil, portafolio: pestanaPortafolio, recursos: pestanaRecursos, contacto: pestanaContacto, publicar: pestanaPublicar }[pestana]();
    cuerpo.append(...contenido.flat());
    cuerpo.scrollTop = scroll;
    marcarEstado();
  }

  function marcarEstado(ok = true) {
    if (!estado) return;
    const pend = W.state.pendiente;
    estado.textContent = '';
    estado.classList.toggle('mal', !ok);
    estado.classList.toggle('pendiente', ok && pend);
    const txt = !ok ? '⚠ Sin espacio para el borrador'
      : publicando ? 'Publicando…'
      : pend ? (conServidor() ? '● Cambios sin publicar' : '● Borrador en este navegador')
      : '✓ Todo publicado';
    estado.append(h('span', { text: txt }));
    if (pend && conServidor()) estado.append(btn(publicando ? 'Publicando…' : 'Publicar', publicar, 'ed-btn-pri ed-btn-mini', 'subir'));
  }

  function aviso(txt, malo) {
    const t = h('div', { class: 'ed-toast' + (malo ? ' mal' : ''), role: 'status', text: txt });
    document.body.append(t);
    requestAnimationFrame(() => t.classList.add('ver'));
    setTimeout(() => { t.classList.remove('ver'); setTimeout(() => t.remove(), 300); }, 3000);
  }

  function irA(idSeccion) {
    const el = document.querySelector('[data-seccion="' + CSS.escape(idSeccion) + '"]');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    if (window.innerWidth < 1100 && panel) panel.classList.add('min');
  }

  /* ---------- Entrada del dueño ---------- */
  function quitarLogin() { if (login) { login.remove(); login = null; } }

  function mostrarLogin() {
    if (panel) { panel.remove(); panel = cuerpo = estado = null; document.body.classList.remove('editando'); W.salirEdicion(); }
    if (login) return;
    const clave = h('input', { type: 'password', autocomplete: 'current-password', placeholder: 'Tu contraseña', required: true, 'aria-label': 'Contraseña' });
    const error = h('p', { class: 'ed-login-error', role: 'alert' });
    const entrar = h('button', { type: 'submit', class: 'ed-btn ed-btn-pri ed-ancho', text: 'Entrar' });
    const form = h('form', { class: 'ed-login-caja', onsubmit: async (e) => {
      e.preventDefault();
      error.textContent = '';
      entrar.disabled = true;
      entrar.textContent = 'Entrando…';
      try {
        const r = await api('login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: clave.value }) });
        token.poner(r.token);
        quitarLogin();
        abrirPanel();
      } catch (err) {
        error.textContent = err.message === 'Error 404' ? 'El servidor de edición no está disponible.' : err.message;
        entrar.disabled = false;
        entrar.textContent = 'Entrar';
        clave.select();
      }
    } },
      h('div', { class: 'ed-marca' }, h('b', null, 'WANDER', h('span', { text: '.' })), h('span', { text: 'Editor' })),
      h('h2', { text: 'Hola de nuevo' }),
      h('p', { text: 'Entra con tu contraseña de dueño para editar y publicar el contenido de tu web.' }),
      clave, error, entrar,
      h('button', { type: 'button', class: 'ed-btn ed-btn-txt ed-ancho', text: 'Volver a la web', onclick: salirDelEditor }));
    login = h('div', { class: 'ed-login', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Entrar al editor' }, form);
    document.body.append(login);
    setTimeout(() => clave.focus(), 50);
  }

  function abrirPanel() {
    if (panel) return;
    W.entrarEdicion();
    document.body.classList.add('editando');
    if (document.getElementById('vistaRecursos')) {
      pestana = 'recursos';
      const slug = (location.pathname.match(/\/recursos\/([\w-]+)/) || [])[1];
      const actual = slug && datos().recursos.items.find((r) => r.slug === slug);
      if (actual) recursoAbierto = actual.id;
    }
    const tabs = h('div', { class: 'ed-tabs', role: 'tablist' }, PESTANAS.map(([id, txt]) =>
      h('button', { type: 'button', role: 'tab', class: 'ed-tab', 'data-p': id, text: txt, onclick: () => { pestana = id; pintar(); cuerpo.scrollTop = 0; } })));
    estado = h('div', { class: 'ed-estado' });
    cuerpo = h('div', { class: 'ed-cuerpo' });
    panel = h('aside', { class: 'ed', 'aria-label': 'Editor de contenido' },
      h('div', { class: 'ed-cab' },
        h('div', { class: 'ed-marca' }, h('b', null, 'WANDER', h('span', { text: '.' })), h('span', { text: 'Editor' })),
        h('div', { class: 'ed-acciones' },
          btnIco('min', 'Minimizar', () => panel.classList.toggle('min'), 'ed-min'),
          btnIco('cerrar', 'Cerrar editor', cerrar))),
      tabs, cuerpo, estado);
    panel.querySelector('.ed-cab').addEventListener('click', (e) => { if (panel.classList.contains('min') && !e.target.closest('.ed-ico')) panel.classList.remove('min'); });
    document.body.append(panel);
    pintar();
    W.render();
    if (W.state.pendiente) aviso(conServidor() ? 'Tienes cambios sin publicar de la última vez' : 'Recuperado tu borrador');
  }

  function cerrar() {
    if (panel && W.state.pendiente && conServidor() &&
        !confirm('Tienes cambios sin publicar. Se guardan en este navegador para la próxima vez, pero tus clientes no los verán hasta que publiques. ¿Salir del editor?')) return;
    salirDelEditor();
  }

  function salirDelEditor() {
    quitarLogin();
    if (panel) { panel.remove(); panel = cuerpo = estado = null; }
    document.body.classList.remove('editando');
    if (/^#editar/.test(location.hash)) history.replaceState(null, '', location.pathname + location.search);
    W.salirEdicion();
  }

  async function abrir() {
    if (panel || login) return;
    await W.listo;
    if (conServidor() && !token.leer()) mostrarLogin();
    else abrirPanel();
  }

  document.addEventListener('wander:guardado', (e) => marcarEstado(e.detail.ok));

  const debeAbrir = () => /^#editar/.test(location.hash) || new URLSearchParams(location.search).has('editar');
  window.addEventListener('hashchange', () => { if (debeAbrir()) abrir(); });
  if (debeAbrir()) abrir();
})();
