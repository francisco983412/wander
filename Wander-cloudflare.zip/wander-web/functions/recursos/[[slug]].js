/* WANDER · Enlace propio de cada recurso (/recursos/nombre-del-recurso)
   Sirve la página de la biblioteca; el navegador muestra la ficha según la dirección.
   (Las cabeceras de _headers no se aplican a las Functions, por eso se repiten aquí.) */
const SEGURIDAD = {
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob: https:; media-src 'self' https: blob:; frame-src https://www.youtube-nocookie.com https://www.youtube.com https://player.vimeo.com https://drive.google.com https://www.instagram.com https://www.tiktok.com; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'; worker-src 'none'; manifest-src 'self'; upgrade-insecure-requests",
  'Strict-Transport-Security': 'max-age=63072000; includeSubDomains; preload',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=(), browsing-topics=()',
  'Cross-Origin-Opener-Policy': 'same-origin'
};

export async function onRequest({ request, env }) {
  const url = new URL(request.url);
  url.pathname = '/recursos';
  url.search = '';
  const pagina = await env.ASSETS.fetch(url.toString());
  const headers = new Headers(pagina.headers);
  for (const [k, v] of Object.entries(SEGURIDAD)) headers.set(k, v);
  return new Response(pagina.body, { status: pagina.status, headers });
}
